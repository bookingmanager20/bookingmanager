﻿namespace Package.AAD.Security
{
    public class ApplicationRoles
    {
        public const string Admins = "Admins";
        public const string Partners = "Partners";
        public const string SFRSUsers = "SFRSUsers";
    }
}
