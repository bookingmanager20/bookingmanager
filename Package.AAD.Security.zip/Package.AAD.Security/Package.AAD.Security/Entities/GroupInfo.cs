﻿namespace Package.AAD.Security.Entities
{
    public class GroupInfo
    {
        public string DisplayName { get; set; }
        public string Id { get; set; }
    }
}
