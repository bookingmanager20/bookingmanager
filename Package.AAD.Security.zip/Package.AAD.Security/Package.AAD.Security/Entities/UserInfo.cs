﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Package.AAD.Security.Entities
{
    public class UserInfo
    {
        public string UserPrincipalName { get; set; }
        public string Id { get; set; }
    }
}
