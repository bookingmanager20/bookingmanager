﻿namespace Package.AAD.Security
{
    public class ApplicationGroupsSetting
    {
        public string Admins { get; set; }
        public string Partners { get; set; }
        public string SFRSUsers { get; set; }
    }
}
